

###################
Crie o seu próprio Jogo da Memória Genius com Arduíno
###################

Neste Vídeo vamos aprender a como prototipar o jogo da memória Genius da Estrela, que foi sensação das crianças nos anos 80 e 90.

*******************
Link com instruções em vídeo: https://youtu.be/8ibVIUVA95k
*******************

Lista de Dispositivos:

- 1 Arduíno Uno;
- 1 Protoboard;
- 4 Resistores de 300 ohms
- 4 Chaves Momentâneas (Push Button)
- 1 Buzzer
- 4 Leds de Cores Diferentes
- Jumpers (Macho/Macho)


Todos os dispositivos usados neste vídeo você encontra no Kit de Arduino Iniciante V8 da Robocore neste Link: http://bit.ly/2UfXYvK




